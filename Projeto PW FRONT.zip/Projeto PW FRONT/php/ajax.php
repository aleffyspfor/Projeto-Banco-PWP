<?php
var_dump($_REQUEST);
var_dump($_FILES);